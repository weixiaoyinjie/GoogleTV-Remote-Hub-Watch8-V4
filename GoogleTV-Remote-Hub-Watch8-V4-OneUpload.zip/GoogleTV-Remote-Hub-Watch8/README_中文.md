# Google TV Remote Hub · Watch 8 V4 双圆盘 · YouTube/Netflix 快捷版

## 核心变化：只更新前两页的外观、按钮布局

- **第一页「遥控」**：整个圆形屏幕用来放大方向盘。中间**唯一一个「确定」键**，圆环上/下/左/右为 TV 方向键；顶端电源、音量−、音量+；底端返回、菜单、主页。**圆盘左侧 YouTube、右侧 Netflix** 两个快捷键（带文字标识），不占用中央确定键或方向控制区。
- **第二页「媒体」**：相同圆形方向盘，中央**唯一一个「确定」键**；默认环形操作为顶部播放/暂停、左边上一首、右边下一首、底部停止；圆盘左右外侧有快退、快进；顶端电源和音量−/音量+；底端 Kodi、Qobuz、「方向」模式切换。
- **媒体「方向」按钮**：按下后，圆环四方切为 TV ↑↓←→，中央「确定」不变；同一位置的按钮变为「播放」，按下即可返回媒体四键。快进/快退始终可用。
- **第一页、第二页全屏优化**：去掉原版在这两页占位置的状态栏、翻页按钮与长标题，利用圆形显示区域，底部用一行「↑↓ 翻页」提醒。上下滑动、旋转表圈切换页面；轻点最下方的「翻页」文字还可前进一页。轻点顶部页标题可查看当前运行状态。
- **其余第 3–6 页内容保留**，包含电视 App 管理、连接、首次配对、启动模式与设置。旧的 2 个独立桌面/表盘快捷入口仍然可选：「TV 遥控」「TV 媒体」。

## 原有功能保留

- Google TV Remote v2 协议、TLS 连接、NSD 搜索、六位码配对及证书校验未修改。
- `applicationId` 仍然为 `com.cecbridge.remotev2.wear`；SharedPreferences `google_tv_remote_v2` 和原始配对、电视 IP、自定义 TV App 配置字段不变。
- YouTube (`com.google.android.youtube.tv`)、Netflix (`com.netflix.ninja`) 沿用与 Kodi、Qobuz 相同的 `launchViaPlay` 启动方式，并受第六页启动模式控制。它们发送到 **Google TV**，不是在手表上安装或启动应用。
- Kodi (`org.xbmc.kodi`) 和 Qobuz (`com.qobuz.music`) 启动仍采用此前的 **Google Play 链接模式**。不保证电视直接启动应用：具体取决于电视 Google Play 和 Google TV Remote v2 对 App Link 的处理。
- 第六页的启动方式（直启尝试 / 自动确认 / 手动确认）仍然有效。建议保持手动确认，避免误操作。
- 电源是遥控器 keycode 26 的电源切换指令（并非硬件 HDMI-CEC）。媒体键能否生效取决于电视播放器。

## 一次上传 GitHub 编译（无需解压 ZIP）

1. 创建 GitHub 仓库 `GoogleTV-Remote-Hub-Watch8-V4`。
2. 上传 `GoogleTV-Remote-Hub-Watch8-V4-OneUpload.zip` 到仓库根目录（不要解压）。
3. 在仓库中创建 `.github/workflows/build-apk.yml` 文件，内容复制本次单独附上的 `build-apk.yml`。
4. GitHub → Actions → `Build Google TV Remote Hub Watch8 APK` → Run workflow。
5. 下载构建产物 `GoogleTV-Remote-Hub-Watch8-V4-APK`，解压其中的 `watch8-debug.apk` 安装到手表。

## 安装与风险

仓库构建的 debug APK 不一定和原先 APK 使用相同签名。即使包名未变，签名不匹配也无法直接覆盖安装。卸载手表上原版会删除原有配对信息和自定义 App 数据，需重新六位码配对。想无损升级请使用原版相同签名密钥。

## 静态检查与限制

已进行 ZIP 内容、资源 XML、按键与页面布局源码核对。当前环境不包含 Android SDK / Gradle，未能进行完整 Android APK 编译，也无法承诺真机渲染和电视遥控效果；请使用 GitHub Actions 实际编译验证。
